import { useMemo, useState } from 'react';

import { Card, CardContent } from '@openzeppelin/ui-components';
import { ContractActionBar, ContractStateWidget, TransactionForm } from '@openzeppelin/ui-renderer';
import type {
  ContractAdapter,
  ContractSchema,
  ExecutionConfig,
  RenderFormSchema,
} from '@openzeppelin/ui-types';
import { cn } from '@openzeppelin/ui-utils';

// Props for GeneratedForm
interface GeneratedFormProps {
  adapter: ContractAdapter;
  isWalletConnected?: boolean;
}

/**
 * Generated Transaction Form for mint_
 *
 * This component renders a form for interacting with a blockchain contract.
 * It uses the shared renderer package which ensures consistent behavior
 * with the preview in the builder app.
 */
export default function GeneratedForm({ adapter, isWalletConnected }: GeneratedFormProps) {
  // TODO: Enable this useEffect as a fallback?
  // If the adapter supports runtime schema loading (e.g., via Etherscan)
  // and the injected schema is missing or invalid, this could attempt to load it.
  /*
  const [contractSchema, setContractSchema] = useState<ContractSchema | null>(null);
  */
  const [isWidgetVisible, setIsWidgetVisible] = useState(false);
  const [loadError, _setLoadError] = useState<Error | null>(null);

  // Form schema generated from the builder and transformed by FormSchemaFactory
  // Memoized to maintain stable reference across re-renders and prevent form resets
  const formSchema: RenderFormSchema = useMemo(() => {
    return {
      layout: {
        columns: 1,
        spacing: 'normal',
        labelPosition: 'top',
      },
      validation: {
        mode: 'onChange',
        showErrors: 'inline',
      },
      theme: {},
      functionId: 'mint_',
      title: 'Mint Form',
      description: 'Form for interacting with the Mint function.',
      contractAddress: '0xf9C8777aD204Fe8c5Af679791c2d5F81e460dc88',
      id: 'form-mint_',
      fields: [],
      submitButton: {
        text: 'Execute Mint Form',
        loadingText: 'Processing...',
        variant: 'primary',
      },
    };
  }, []);

  // Contract schema injected by generator (loaded or imported by the user)
  // Memoized to maintain stable reference across re-renders and prevent form resets
  const contractSchema: ContractSchema = useMemo(() => {
    return {
      ecosystem: 'evm',
      name: 'ContractFromABI',
      address: '0x461C0dC291FdE5271e2BaB8d7595BD5ec78ce938',
      functions: [
        {
          id: 'allowlistMint_bytes',
          name: 'allowlistMint',
          displayName: 'Allowlist Mint',
          inputs: [
            {
              name: '_signature',
              type: 'bytes',
              displayName: 'signature',
            },
          ],
          outputs: [],
          type: 'function',
          stateMutability: 'payable',
          modifiesState: true,
        },
        {
          id: 'approve_address_uint256',
          name: 'approve',
          displayName: 'Approve',
          inputs: [
            {
              name: 'to',
              type: 'address',
              displayName: 'To',
            },
            {
              name: 'tokenId',
              type: 'uint256',
              displayName: 'Token Id',
            },
          ],
          outputs: [],
          type: 'function',
          stateMutability: 'nonpayable',
          modifiesState: true,
        },
        {
          id: 'mint_',
          name: 'mint',
          displayName: 'Mint',
          inputs: [],
          outputs: [],
          type: 'function',
          stateMutability: 'payable',
          modifiesState: true,
        },
        {
          id: 'ownerMint_address_uint256',
          name: 'ownerMint',
          displayName: 'Owner Mint',
          inputs: [
            {
              name: 'to',
              type: 'address',
              displayName: 'To',
            },
            {
              name: 'count',
              type: 'uint256',
              displayName: 'Count',
            },
          ],
          outputs: [],
          type: 'function',
          stateMutability: 'nonpayable',
          modifiesState: true,
        },
        {
          id: 'renounceOwnership_',
          name: 'renounceOwnership',
          displayName: 'Renounce Ownership',
          inputs: [],
          outputs: [],
          type: 'function',
          stateMutability: 'nonpayable',
          modifiesState: true,
        },
        {
          id: 'safeTransferFrom_address_address_uint256',
          name: 'safeTransferFrom',
          displayName: 'Safe Transfer From',
          inputs: [
            {
              name: 'from',
              type: 'address',
              displayName: 'From',
            },
            {
              name: 'to',
              type: 'address',
              displayName: 'To',
            },
            {
              name: 'tokenId',
              type: 'uint256',
              displayName: 'Token Id',
            },
          ],
          outputs: [],
          type: 'function',
          stateMutability: 'nonpayable',
          modifiesState: true,
        },
        {
          id: 'safeTransferFrom_address_address_uint256_bytes',
          name: 'safeTransferFrom',
          displayName: 'Safe Transfer From',
          inputs: [
            {
              name: 'from',
              type: 'address',
              displayName: 'From',
            },
            {
              name: 'to',
              type: 'address',
              displayName: 'To',
            },
            {
              name: 'tokenId',
              type: 'uint256',
              displayName: 'Token Id',
            },
            {
              name: 'data',
              type: 'bytes',
              displayName: 'Data',
            },
          ],
          outputs: [],
          type: 'function',
          stateMutability: 'nonpayable',
          modifiesState: true,
        },
        {
          id: 'setAllowlistOnly_bool',
          name: 'setAllowlistOnly',
          displayName: 'Set Allowlist Only',
          inputs: [
            {
              name: '_allowlist',
              type: 'bool',
              displayName: 'allowlist',
            },
          ],
          outputs: [],
          type: 'function',
          stateMutability: 'nonpayable',
          modifiesState: true,
        },
        {
          id: 'setApprovalForAll_address_bool',
          name: 'setApprovalForAll',
          displayName: 'Set Approval For All',
          inputs: [
            {
              name: 'operator',
              type: 'address',
              displayName: 'Operator',
            },
            {
              name: 'approved',
              type: 'bool',
              displayName: 'Approved',
            },
          ],
          outputs: [],
          type: 'function',
          stateMutability: 'nonpayable',
          modifiesState: true,
        },
        {
          id: 'setMintOpen_bool',
          name: 'setMintOpen',
          displayName: 'Set Mint Open',
          inputs: [
            {
              name: 'open',
              type: 'bool',
              displayName: 'Open',
            },
          ],
          outputs: [],
          type: 'function',
          stateMutability: 'nonpayable',
          modifiesState: true,
        },
        {
          id: 'setSigner_address',
          name: 'setSigner',
          displayName: 'Set Signer',
          inputs: [
            {
              name: '_signer',
              type: 'address',
              displayName: 'signer',
            },
          ],
          outputs: [],
          type: 'function',
          stateMutability: 'nonpayable',
          modifiesState: true,
        },
        {
          id: 'transferFrom_address_address_uint256',
          name: 'transferFrom',
          displayName: 'Transfer From',
          inputs: [
            {
              name: 'from',
              type: 'address',
              displayName: 'From',
            },
            {
              name: 'to',
              type: 'address',
              displayName: 'To',
            },
            {
              name: 'tokenId',
              type: 'uint256',
              displayName: 'Token Id',
            },
          ],
          outputs: [],
          type: 'function',
          stateMutability: 'nonpayable',
          modifiesState: true,
        },
        {
          id: 'transferOwnership_address',
          name: 'transferOwnership',
          displayName: 'Transfer Ownership',
          inputs: [
            {
              name: 'newOwner',
              type: 'address',
              displayName: 'New Owner',
            },
          ],
          outputs: [],
          type: 'function',
          stateMutability: 'nonpayable',
          modifiesState: true,
        },
        {
          id: 'withdraw_',
          name: 'withdraw',
          displayName: 'Withdraw',
          inputs: [],
          outputs: [],
          type: 'function',
          stateMutability: 'nonpayable',
          modifiesState: true,
        },
        {
          id: 'allowlistOnly_',
          name: 'allowlistOnly',
          displayName: 'Allowlist Only',
          inputs: [],
          outputs: [
            {
              name: '',
              type: 'bool',
              displayName: 'Parameter (bool)',
            },
          ],
          type: 'function',
          stateMutability: 'view',
          modifiesState: false,
        },
        {
          id: 'auraNames_uint256',
          name: 'auraNames',
          displayName: 'Aura Names',
          inputs: [
            {
              name: '',
              type: 'uint256',
              displayName: 'Parameter (uint256)',
            },
          ],
          outputs: [
            {
              name: '',
              type: 'string',
              displayName: 'Parameter (string)',
            },
          ],
          type: 'function',
          stateMutability: 'view',
          modifiesState: false,
        },
        {
          id: 'balanceOf_address',
          name: 'balanceOf',
          displayName: 'Balance Of',
          inputs: [
            {
              name: 'owner',
              type: 'address',
              displayName: 'Owner',
            },
          ],
          outputs: [
            {
              name: '',
              type: 'uint256',
              displayName: 'Parameter (uint256)',
            },
          ],
          type: 'function',
          stateMutability: 'view',
          modifiesState: false,
        },
        {
          id: 'bgNames_uint256',
          name: 'bgNames',
          displayName: 'Bg Names',
          inputs: [
            {
              name: '',
              type: 'uint256',
              displayName: 'Parameter (uint256)',
            },
          ],
          outputs: [
            {
              name: '',
              type: 'string',
              displayName: 'Parameter (string)',
            },
          ],
          type: 'function',
          stateMutability: 'view',
          modifiesState: false,
        },
        {
          id: 'comboUsed_uint256',
          name: 'comboUsed',
          displayName: 'Combo Used',
          inputs: [
            {
              name: '',
              type: 'uint256',
              displayName: 'Parameter (uint256)',
            },
          ],
          outputs: [
            {
              name: '',
              type: 'bool',
              displayName: 'Parameter (bool)',
            },
          ],
          type: 'function',
          stateMutability: 'view',
          modifiesState: false,
        },
        {
          id: 'feeRecipient_',
          name: 'feeRecipient',
          displayName: 'Fee Recipient',
          inputs: [],
          outputs: [
            {
              name: '',
              type: 'address',
              displayName: 'Parameter (address)',
            },
          ],
          type: 'function',
          stateMutability: 'view',
          modifiesState: false,
        },
        {
          id: 'getApproved_uint256',
          name: 'getApproved',
          displayName: 'Get Approved',
          inputs: [
            {
              name: 'tokenId',
              type: 'uint256',
              displayName: 'Token Id',
            },
          ],
          outputs: [
            {
              name: '',
              type: 'address',
              displayName: 'Parameter (address)',
            },
          ],
          type: 'function',
          stateMutability: 'view',
          modifiesState: false,
        },
        {
          id: 'getTraits_uint256',
          name: 'getTraits',
          displayName: 'Get Traits',
          inputs: [
            {
              name: 'tokenId',
              type: 'uint256',
              displayName: 'Token Id',
            },
          ],
          outputs: [
            {
              name: '',
              type: 'uint8[4]',
              displayName: 'Parameter (uint8[4])',
            },
          ],
          type: 'function',
          stateMutability: 'view',
          modifiesState: false,
        },
        {
          id: 'isApprovedForAll_address_address',
          name: 'isApprovedForAll',
          displayName: 'Is Approved For All',
          inputs: [
            {
              name: 'owner',
              type: 'address',
              displayName: 'Owner',
            },
            {
              name: 'operator',
              type: 'address',
              displayName: 'Operator',
            },
          ],
          outputs: [
            {
              name: '',
              type: 'bool',
              displayName: 'Parameter (bool)',
            },
          ],
          type: 'function',
          stateMutability: 'view',
          modifiesState: false,
        },
        {
          id: 'lastMintTime_address',
          name: 'lastMintTime',
          displayName: 'Last Mint Time',
          inputs: [
            {
              name: '',
              type: 'address',
              displayName: 'Parameter (address)',
            },
          ],
          outputs: [
            {
              name: '',
              type: 'uint256',
              displayName: 'Parameter (uint256)',
            },
          ],
          type: 'function',
          stateMutability: 'view',
          modifiesState: false,
        },
        {
          id: 'MAX_PER_WALLET_',
          name: 'MAX_PER_WALLET',
          displayName: 'M A X_ P E R_ W A L L E T',
          inputs: [],
          outputs: [
            {
              name: '',
              type: 'uint256',
              displayName: 'Parameter (uint256)',
            },
          ],
          type: 'function',
          stateMutability: 'view',
          modifiesState: false,
        },
        {
          id: 'MAX_SUPPLY_',
          name: 'MAX_SUPPLY',
          displayName: 'M A X_ S U P P L Y',
          inputs: [],
          outputs: [
            {
              name: '',
              type: 'uint256',
              displayName: 'Parameter (uint256)',
            },
          ],
          type: 'function',
          stateMutability: 'view',
          modifiesState: false,
        },
        {
          id: 'MINT_COOLDOWN_',
          name: 'MINT_COOLDOWN',
          displayName: 'M I N T_ C O O L D O W N',
          inputs: [],
          outputs: [
            {
              name: '',
              type: 'uint256',
              displayName: 'Parameter (uint256)',
            },
          ],
          type: 'function',
          stateMutability: 'view',
          modifiesState: false,
        },
        {
          id: 'MINT_PRICE_',
          name: 'MINT_PRICE',
          displayName: 'M I N T_ P R I C E',
          inputs: [],
          outputs: [
            {
              name: '',
              type: 'uint256',
              displayName: 'Parameter (uint256)',
            },
          ],
          type: 'function',
          stateMutability: 'view',
          modifiesState: false,
        },
        {
          id: 'mintOpen_',
          name: 'mintOpen',
          displayName: 'Mint Open',
          inputs: [],
          outputs: [
            {
              name: '',
              type: 'bool',
              displayName: 'Parameter (bool)',
            },
          ],
          type: 'function',
          stateMutability: 'view',
          modifiesState: false,
        },
        {
          id: 'name_',
          name: 'name',
          displayName: 'Name',
          inputs: [],
          outputs: [
            {
              name: '',
              type: 'string',
              displayName: 'Parameter (string)',
            },
          ],
          type: 'function',
          stateMutability: 'view',
          modifiesState: false,
        },
        {
          id: 'owner_',
          name: 'owner',
          displayName: 'Owner',
          inputs: [],
          outputs: [
            {
              name: '',
              type: 'address',
              displayName: 'Parameter (address)',
            },
          ],
          type: 'function',
          stateMutability: 'view',
          modifiesState: false,
        },
        {
          id: 'OWNER_RESERVE_',
          name: 'OWNER_RESERVE',
          displayName: 'O W N E R_ R E S E R V E',
          inputs: [],
          outputs: [
            {
              name: '',
              type: 'uint256',
              displayName: 'Parameter (uint256)',
            },
          ],
          type: 'function',
          stateMutability: 'view',
          modifiesState: false,
        },
        {
          id: 'ownerOf_uint256',
          name: 'ownerOf',
          displayName: 'Owner Of',
          inputs: [
            {
              name: 'tokenId',
              type: 'uint256',
              displayName: 'Token Id',
            },
          ],
          outputs: [
            {
              name: '',
              type: 'address',
              displayName: 'Parameter (address)',
            },
          ],
          type: 'function',
          stateMutability: 'view',
          modifiesState: false,
        },
        {
          id: 'ROYALTY_BPS_',
          name: 'ROYALTY_BPS',
          displayName: 'R O Y A L T Y_ B P S',
          inputs: [],
          outputs: [
            {
              name: '',
              type: 'uint96',
              displayName: 'Parameter (uint96)',
            },
          ],
          type: 'function',
          stateMutability: 'view',
          modifiesState: false,
        },
        {
          id: 'royaltyInfo_uint256_uint256',
          name: 'royaltyInfo',
          displayName: 'Royalty Info',
          inputs: [
            {
              name: 'tokenId',
              type: 'uint256',
              displayName: 'Token Id',
            },
            {
              name: 'salePrice',
              type: 'uint256',
              displayName: 'Sale Price',
            },
          ],
          outputs: [
            {
              name: 'receiver',
              type: 'address',
              displayName: 'Receiver',
            },
            {
              name: 'amount',
              type: 'uint256',
              displayName: 'Amount',
            },
          ],
          type: 'function',
          stateMutability: 'view',
          modifiesState: false,
        },
        {
          id: 'royaltyRecipient_',
          name: 'royaltyRecipient',
          displayName: 'Royalty Recipient',
          inputs: [],
          outputs: [
            {
              name: '',
              type: 'address',
              displayName: 'Parameter (address)',
            },
          ],
          type: 'function',
          stateMutability: 'view',
          modifiesState: false,
        },
        {
          id: 'signer_',
          name: 'signer',
          displayName: 'Signer',
          inputs: [],
          outputs: [
            {
              name: '',
              type: 'address',
              displayName: 'Parameter (address)',
            },
          ],
          type: 'function',
          stateMutability: 'view',
          modifiesState: false,
        },
        {
          id: 'stoneNames_uint256',
          name: 'stoneNames',
          displayName: 'Stone Names',
          inputs: [
            {
              name: '',
              type: 'uint256',
              displayName: 'Parameter (uint256)',
            },
          ],
          outputs: [
            {
              name: '',
              type: 'string',
              displayName: 'Parameter (string)',
            },
          ],
          type: 'function',
          stateMutability: 'view',
          modifiesState: false,
        },
        {
          id: 'supportsInterface_bytes4',
          name: 'supportsInterface',
          displayName: 'Supports Interface',
          inputs: [
            {
              name: 'interfaceId',
              type: 'bytes4',
              displayName: 'Interface Id',
            },
          ],
          outputs: [
            {
              name: '',
              type: 'bool',
              displayName: 'Parameter (bool)',
            },
          ],
          type: 'function',
          stateMutability: 'view',
          modifiesState: false,
        },
        {
          id: 'symbol_',
          name: 'symbol',
          displayName: 'Symbol',
          inputs: [],
          outputs: [
            {
              name: '',
              type: 'string',
              displayName: 'Parameter (string)',
            },
          ],
          type: 'function',
          stateMutability: 'view',
          modifiesState: false,
        },
        {
          id: 'tokenURI_uint256',
          name: 'tokenURI',
          displayName: 'Token U R I',
          inputs: [
            {
              name: 'tokenId',
              type: 'uint256',
              displayName: 'Token Id',
            },
          ],
          outputs: [
            {
              name: '',
              type: 'string',
              displayName: 'Parameter (string)',
            },
          ],
          type: 'function',
          stateMutability: 'view',
          modifiesState: false,
        },
        {
          id: 'totalSupply_',
          name: 'totalSupply',
          displayName: 'Total Supply',
          inputs: [],
          outputs: [
            {
              name: '',
              type: 'uint256',
              displayName: 'Parameter (uint256)',
            },
          ],
          type: 'function',
          stateMutability: 'view',
          modifiesState: false,
        },
        {
          id: 'walletMinted_address',
          name: 'walletMinted',
          displayName: 'Wallet Minted',
          inputs: [
            {
              name: '',
              type: 'address',
              displayName: 'Parameter (address)',
            },
          ],
          outputs: [
            {
              name: '',
              type: 'uint256',
              displayName: 'Parameter (uint256)',
            },
          ],
          type: 'function',
          stateMutability: 'view',
          modifiesState: false,
        },
        {
          id: 'wolfNames_uint256',
          name: 'wolfNames',
          displayName: 'Wolf Names',
          inputs: [
            {
              name: '',
              type: 'uint256',
              displayName: 'Parameter (uint256)',
            },
          ],
          outputs: [
            {
              name: '',
              type: 'string',
              displayName: 'Parameter (string)',
            },
          ],
          type: 'function',
          stateMutability: 'view',
          modifiesState: false,
        },
      ],
    };
  }, []);

  // Execution configuration selected in the builder
  // Memoized to maintain stable reference across re-renders
  const executionConfig: ExecutionConfig | undefined = useMemo(() => {
    return {
      method: 'eoa',
      allowAny: true,
    };
  }, []);

  const contractAddress = formSchema.contractAddress;

  // TODO: Enable this useEffect as a fallback?
  // If the adapter supports runtime schema loading (e.g., via Etherscan)
  // and the injected schema is missing or invalid, this could attempt to load it.
  /*
  useEffect(() => {
    setLoadError(null);
    setContractSchema(null);

    if (contractAddress) {
      adapter
        .loadContract(contractAddress)
        .then(setContractSchema)
        .catch((err: unknown) => {
          // Catch error during contract loading
          logger.error('GeneratedForm', 'Error loading contract schema:', err);
          // Create a new Error object if caught value is not already one
          const errorToSet =
            err instanceof Error ? err : new Error('Failed to load contract state');
          setLoadError(errorToSet);
          setContractSchema(null);
        });
    } else {
      setContractSchema(null);
    }
  }, [contractAddress, adapter]);
  */

  // Decide which schema to use: prioritize injected, fallback maybe later?
  const schemaToUse = contractSchema; // Sticking to injected schema for now

  const toggleWidget = () => {
    setIsWidgetVisible((prev: boolean) => !prev);
  };

  return (
    <div className="space-y-6">
      {/* Contract Action Bar - consistent with builder app */}
      {adapter.networkConfig && (
        <ContractActionBar
          networkConfig={adapter.networkConfig}
          contractAddress={contractAddress}
          onToggleContractState={toggleWidget}
          isWidgetExpanded={isWidgetVisible}
        />
      )}

      <div className="flex gap-4">
        {/* Contract State Widget on the left side - always mounted to prevent remount churn */}
        {contractAddress && (
          <div
            className={cn(
              'shrink-0 transition-all',
              isWidgetVisible ? 'md:w-80 md:mr-6' : 'md:w-0'
            )}
          >
            <div className="sticky top-4">
              <ContractStateWidget
                contractSchema={schemaToUse}
                contractAddress={contractAddress}
                adapter={adapter}
                isVisible={isWidgetVisible}
                onToggle={toggleWidget}
                error={loadError}
              />
            </div>
          </div>
        )}

        {/* Main form on the right side */}
        <div className="flex-1">
          <Card>
            <CardContent className="space-y-4">
              <TransactionForm
                schema={formSchema}
                contractSchema={contractSchema}
                adapter={adapter}
                isWalletConnected={isWalletConnected}
                executionConfig={executionConfig}
              />
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
